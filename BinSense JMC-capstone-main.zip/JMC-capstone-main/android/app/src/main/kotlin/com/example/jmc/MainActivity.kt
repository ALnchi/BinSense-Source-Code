package com.example.jmc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
